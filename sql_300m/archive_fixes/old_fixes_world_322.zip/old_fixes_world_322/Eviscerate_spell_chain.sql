

/*

Eviscerate_spell_chain.sql

����������� ������ �� ������ http://www.wowhead.com/?spell=2098 � ��� �����

*/


DELETE FROM `spell_chain` WHERE `first_spell` = '2098';


#�����

/*

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (2098, 0, 2098, 1, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (6760, 2098, 2098, 2, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (6761, 6760, 2098, 3, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (6762, 6761, 2098, 4, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (8623, 6762, 2098, 5, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (8624, 8623, 2098, 6, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (11299, 8624, 2098, 7, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (11300, 11299, 2098, 8, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (31016, 11300, 2098, 9, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (26865, 31016, 2098, 10, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (48667, 26865, 2098, 11, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (48668, 48667, 2098, 12, 0);

*/
