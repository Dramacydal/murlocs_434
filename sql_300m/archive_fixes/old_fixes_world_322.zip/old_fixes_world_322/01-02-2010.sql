

/*

01-02-2010.sql

*/


UPDATE `creature_template` SET `faction_A` = 35, `faction_H` = 35, `unit_flags` = 0 WHERE `entry` in (30352,30755);


#EoF