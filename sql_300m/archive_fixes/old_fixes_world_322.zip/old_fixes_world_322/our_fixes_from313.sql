
/*

Furious Attacks

*/

DELETE FROM  spell_proc_event WHERE entry IN (46910, 46911);
INSERT INTO spell_proc_event (`entry`, `SchoolMask`, `SpellFamilyName`, `SpellFamilyMask0`, `SpellFamilyMask1`, `SpellFamilyMask2`, `procFlags`, `procEx`, `ppmRate`, `CustomChance`, `Cooldown`) VALUES 
('46910', '0', '0', '0', '0', '0', '0', '0', '3', '0', '0'),
('46911', '0', '0', '0', '0', '0', '0', '0', '6', '0', '0');


/*

Darkmoon Card: Death

*/


DELETE FROM spell_bonus_data WHERE entry IN (60203);

INSERT INTO spell_bonus_data
   (`entry`, `direct_bonus`, `dot_bonus`, `ap_bonus`, `comments`)
VALUES
   (60203, 0, 0, 0, 'Darkmoon Card: Death');


/*

Killing Machine
http://www.wowwiki.com/Killing_Machine
Rank 1 http://www.wowhead.com/?spell=51123
Rank 2 http://www.wowhead.com/?spell=51127
Rank 3 http://www.wowhead.com/?spell=51128
Rank 4 http://www.wowhead.com/?spell=51129
Rank 5 http://www.wowhead.com/?spell=51130

ppmRate

*/


DELETE FROM spell_proc_event WHERE entry IN (51123, 51127, 51128, 51129, 51130);

INSERT INTO spell_proc_event VALUES 
(51123, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0),
(51127, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0),
(51128, 0, 0, 0, 0, 0, 0, 2, 3, 0, 0),
(51129, 0, 0, 0, 0, 0, 0, 2, 4, 0, 0),
(51130, 0, 0, 0, 0, 0, 0, 2, 5, 0, 0);


/*

spell bonus data for Druid Lacerate

*/


DELETE FROM `spell_bonus_data` where entry in (33745, 48567, 48568);

INSERT INTO `spell_bonus_data` VALUES
(33745, 0, 0, 0, "Druid - Lacerate"),
(48567, 0, 0, 0, "Druid - Lacerate"),
(48568, 0, 0, 0, "Druid - Lacerate");


/*

Taste for Blood

*/

-- Taste for Blood (1/2/3 ranks)
DELETE FROM spell_proc_event WHERE entry IN (56636, 56637, 56638);
INSERT INTO spell_proc_event VALUES
(56636 , 0, 4, 32, 0, 0, 0, 0, 0, 0, 6),
(56637 , 0, 4, 32, 0, 0, 0, 0, 0, 0, 6),
(56638 , 0, 4, 32, 0, 0, 0, 0, 0, 0, 6);


#EoF