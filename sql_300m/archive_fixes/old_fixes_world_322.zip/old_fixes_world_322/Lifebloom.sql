
/*

Lifebloom coef

*/

DELETE FROM spell_bonus_data WHERE entry IN (33763);

INSERT INTO spell_bonus_data VALUES
(33763, 0.516, 0.09518, 0, 'Druid - Lifebloom');

#EoF
