

/*

���������� ������� ��� ����� http://www.wowhead.com/?spell=64323

������ ����� http://www.wowhead.com/?item=45912

*/

REPLACE INTO `skill_discovery_template` VALUES ('64297', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64300', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64298', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64299', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64256', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64268', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64313', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64307', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('65245', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64270', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64271', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64273', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64253', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64304', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64246', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64249', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64276', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64274', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64257', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64275', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64314', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64314', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64305', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64279', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64278', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64254', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64251', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64308', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64280', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64281', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64283', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64309', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64282', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64303', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64315', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64284', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64285', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64286', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64310', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64288', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64316', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64289', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64247', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64287', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64294', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64317', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64291', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64248', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64318', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64311', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64250', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64295', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64312', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64252', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64296', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64302', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64255', '64323', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64297', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64300', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64298', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64299', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64256', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64268', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64313', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64307', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('65245', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64270', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64271', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64273', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64253', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64304', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64246', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64249', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64276', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64274', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64257', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64275', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64314', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64314', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64305', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64279', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64278', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64254', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64251', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64308', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64280', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64281', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64283', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64309', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64282', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64303', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64315', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64284', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64285', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64286', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64310', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64288', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64316', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64289', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64247', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64287', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64294', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64317', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64291', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64248', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64318', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64311', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64250', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64295', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64312', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64252', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64296', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64302', '61756', '400', '100');
REPLACE INTO `skill_discovery_template` VALUES ('64255', '61756', '400', '100');

#EoF

