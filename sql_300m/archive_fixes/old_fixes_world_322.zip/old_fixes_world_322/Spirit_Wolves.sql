

/*

Feral Spirit - Spirit Wolf spells and HP

Original sql by ������ (a.k.a DuKJIoHuyC)

http://www.wowwiki.com/Feral_Spirit

*/


#first spell: Bash - http://www.wowhead.com/?spell=58861
UPDATE `creature_template` SET `spell1`='58861' WHERE `entry`='29264';

#second spell: Spirit Hunt - http://www.wowhead.com/?spell=58877
UPDATE `creature_template` SET `spell2`='58877' WHERE `entry`='29264';

#third spell: Spirit Walk - http://www.wowhead.com/?spell=58875
UPDATE `creature_template` SET `spell3`='58875' WHERE `entry`='29264';

#fourth spell: Twin Howl - http://www.wowhead.com/?spell=58857
UPDATE `creature_template` SET `spell4`='58857' WHERE `entry`='29264';


#Spirit Wolf health points - blizzlike
UPDATE `creature_template` SET `minhealth`='12593',`maxhealth`='12593' WHERE `entry`='29264';


#EoF