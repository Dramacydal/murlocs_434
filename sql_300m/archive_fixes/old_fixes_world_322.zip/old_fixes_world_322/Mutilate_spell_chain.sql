

/*

Mutilate_spell_chain.sql

����������� ������ �� ������ http://www.wowhead.com/?spell=1329 � ��� �����

*/


DELETE FROM `spell_chain` WHERE `first_spell` = '1329';


#�����

/*

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (1329, 0, 1329, 1, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (34411, 1329, 1329, 2, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (34412, 34411, 1329, 3, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (34413, 34412, 1329, 4, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (48663, 34413, 1329, 5, 0);

INSERT INTO spell_chain
   (`spell_id`, `prev_spell`, `first_spell`, `rank`, `req_spell`)
VALUES
   (48666, 48663, 1329, 6, 0);

*/