

DELETE FROM command where name IN ('getfrombackup');

INSERT INTO command
   (`name`, `security`, `help`)
VALUES
   ('getfrombackup', 0, 'Syntax: .getfrombackup\r\n\r\nRestores last known character attributes for the proved owner.\r\nCharacters are being restored up from the middle of 2009.');

